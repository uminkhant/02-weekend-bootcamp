import java.util.Scanner;
import java.util.Arrays;

class ArrayDemo{

	static String[] names = new String[0];
	static Scanner sc;
	public static void main(String[] args) {
		sc = new Scanner(System.in);
		askNameAndIndex();
		showNames();
	}

	static void askNameAndIndex(){
		String ask = "";
		do{
			System.out.println("Type Name ");
			String name = sc.nextLine();
			setName(name);
			System.out.println("Do you want more ! y/");
			ask = sc.nextLine();

		}while("y".equals(ask));
	}

	static void  setName(String name){
		String tmp[] = new String[names.length+1];
		for (int i = 0;i < names.length ;i++ ) {
			tmp[i] = names[i];
		}
		tmp[names.length] = name;
		names = tmp;
		//names = Arrays.copyOf(names,names.length+1);
		//names[names.length -1] = name ;
		
	}

	static void showNames(){
		for (String nam : names ) {
			System.out.println("Names :"+nam);
		}
	}
}