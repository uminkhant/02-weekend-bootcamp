class Main{

	public static void main(String[] args) {
		
		 Data d = new Data("sss");	
		// d.setName("Thida");		
		 d.instanceMethod();


		// Data.staticMethod("ss");
		// System.out.println(d.staticName);
		// System.out.println(d.instanceName);
		// System.out.println(d.staticName);


	}
}