class Data{
	static String staticName;
	String instanceName;

	{
		System.out.println("instance block");
	}
	static{
		System.out.println("Static block");
	}

	Data(String str){
		instanceName = str;
		System.out.println("Using constructor");
	}

	static void staticMethod(String instanceName){
		//Data d = new Data();
		//d.instanceMethod();
	}

	void setName (String n){
		instanceName = n;
	}

	void instanceMethod(){
		System.out.println(instanceName);

		//staticMethod();
		// staticName = "Andrew";
		// instanceName = "Sopheia";
		// System.out.println(staticName);
		// System.out.println(instanceName);
	}
}