package pkgTest.folderOne;

public class Employee{
	public void doSomething(){
		System.out.println("do something");
	}

	public static void doStaticSomething(){
		System.out.println("do something");
	}
}