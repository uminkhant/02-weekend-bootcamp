class Person{

	static String name;

	 void show() {
		System.out.println("Person class is using");
	}
}