class Human{

	public static void main(String[] args) {
		setName("Sue",44,true);
		String result = getName();
		System.out.println(result);
	}

	static void setName(String name,int age,boolean type){
		System.out.println(name);
	}

	static String getName(){
		String s = null;
		return s;
	}


}