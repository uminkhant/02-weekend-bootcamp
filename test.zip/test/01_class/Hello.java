class Hello{
	public static void main(String[]arg){
		
		Person pOne = new Person();
		pOne.name = "Sandra";

		Person pTwo = new Person();
		//pTwo.name = "Andrew";

		System.out.println(pTwo.name);
	}

	
}
